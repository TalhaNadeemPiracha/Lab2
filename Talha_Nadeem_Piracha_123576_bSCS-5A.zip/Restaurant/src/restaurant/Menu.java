/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
package restaurant;

/**
 *
 * @author Hamza
 */
public class Menu {
    private String appetizer;
    private String maincourse;
    private String soup;
    private String side_dishes;
    
    private int Time_appetizer;
    
    Menu()
    {

    }
    void select_Menu()
    {
        int opr=0;
        while (opr!=6)
        {
        System.out.println("Enter the dish you want to order !. Press 1 for appetizer. Press 2 for maincourse. Press 3 for Soup. Press 4 for side dishes. !");
        Scanner input_menu=new Scanner(System.in);
        opr=input_menu.nextInt();
        
        }
     if(opr==1)
     {
         select_Appetizer();
     }
     if(opr==2)
     {
         select_maincourse();
     }
     if(opr==3)
     {
         select_soup();
     }
     if(opr==4)
     {
         side_line();
     }
     }
        
       
        
    
 void select_Appetizer()
 {
     int choice=0;
     while(choice!=5)
     {
     System.out.println("Enter what appetizer would you like to order. Press 1 for Fries. Press 2 for Garlic Bread. Press 3 for mushrooms. Press 4 for Shrimps. Press 5 to exit");
       Scanner app=new Scanner(System.in);
       choice= app.nextInt();
       
      
       
     } 
 }
void select_maincourse()
{
    int option=0;
    while (option !=7)
    {
        System.out.println("Enter what maincourse would you like to order. Press 1 for Pizza. Press 2 for Burger. Press 3 for Steak. Press 4 for Fish. Press 5 for Roast. Press 6 for Grilled Chicken. Press 7 for exit!");
       Scanner maincourse=new Scanner(System.in);
       option=maincourse.nextInt();
    }
}
void select_soup()
{
    int select=0;
    while(select!=3)
    {
        System.out.println("Enter the soup you want to order. Press 1 for HotNSour. Press 2 for EggFriedSoup. Press 3 to exit.");
        Scanner soup=new Scanner(System.in);
        select=soup.nextInt();
    }

}
void side_line()
{
    int choose=0;
    while(choose!=4)
    {
        System.out.println("Enter the sideline you want to order. Press 1 for x. Press 2 for y. Press 3 for z. Press 4 for exit");
    Scanner sideline=new Scanner(System.in);
    choose=sideline.nextInt();
    }
    }


}
            
     

