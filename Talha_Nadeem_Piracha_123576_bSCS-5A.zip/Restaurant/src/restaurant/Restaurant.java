/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurant;


import java.util.Scanner;

import java.text.SimpleDateFormat;
import java.util.Calendar;



/**
 *
 * @author Hamza
 */
public class Restaurant {
    private String appetizer;
    private String maincourse;
    private String soup;
    private String side_dishes;
    
    private int Time_appetizer;
    private int Time_maincourse;
    private int Time_soup;
    private int Time_sidedish;
    
    private int total1;
    private int total2;
    private int total3;
    private int total4;
    
    
    
    
    int Bill;
    void select_Menu()
    {
        int opr=0;
        
        while (opr!=6)
        {
           
        System.out.println("Enter the dish you want to order !. Press 1 for appetizer. Press 2 for maincourse. Press 3 for Soup. Press 4 for side dishes. !");
        Scanner input_menu=new Scanner(System.in);
        opr=input_menu.nextInt();
        
        
     if(opr==1)
     {
         select_Appetizer();
     }
      if(opr==2)
     {
         select_maincourse();
     }
      if(opr==3)
     {
         select_soup();
     }
     if(opr==4)
     {
         side_line();
     }
     if(opr==6)
     {
     displayBill();    
     }
     
     }
        
    }
        
    
 void select_Appetizer()
 {
     int choice=0;
     int sum1=0;
      total1=0;
     while(choice!=5)
     {
     System.out.println("Enter what appetizer would you like to order. Press 1 for Fries( Rs250). Press 2 for Garlic Bread(Rs 250). Press 3 for mushrooms(Rs 250 ). Press 4 for Shrimps(Rs 250). Press 5 to exit");
       Scanner app=new Scanner(System.in);
       choice= app.nextInt();
       sum1=sum1+250;
       } 
     total1=total1+sum1;
 }
void select_maincourse()
{
    int option=0;
     total2=0;
    int sum2=0;
    while (option !=7)
    {
        System.out.println("Enter what maincourse would you like to order. Press 1 for Pizza (Rs 350). Press 2 for Burger (Rs 350). Press 3 for Steak (Rs 350). Press 4 for Fish (Rs 350). Press 5 for Roast (Rs 350). Press 6 for Grilled Chicken (Rs 350). Press 7 for exit!");
       Scanner maincourse=new Scanner(System.in);
       option=maincourse.nextInt();
       sum2=sum2+350;
    }
    total2=total2+sum2;
}
public void select_soup()
{
    int select=0;
    int sum3=0;
     total3=0;
    while(select!=3)
    {
        System.out.println("Enter the soup you want to order. Press 1 for HotNSour (Rs 200). Press 2 for EggFriedSoup(Rs 200). Press 3 to exit.");
        Scanner soup=new Scanner(System.in);
        select=soup.nextInt();
        sum3=sum3+ 200;
    }
    total3=total3+sum3;

}
void side_line()
{
    int choose=0;
    total4=0;
    int sum4=0;
    while(choose!=4)
    {
        System.out.println("Enter the sideline you want to order. Press 1 for x (Rs 100). Press 2 for y (Rs 100). Press 3 for z (Rs 100). Press 4 for exit");
    Scanner sideline=new Scanner(System.in);
    choose=sideline.nextInt();
    sum4=sum4+100;
    }
    total4=total4+sum4;
    }
void setTime()
{
    Time_appetizer=10;
    Time_maincourse=15;
    Time_soup=10;
    Time_sidedish=7;
    

}
void displayBill()
{
    Bill=total1+total2+total3+total4;
    System.out.println("The total bill is: "+Bill );
    
    
    
}


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CTime ct = new CTime();
        ct.t();
        
        
        Restaurant rt=new Restaurant();
        rt.select_Menu();
        
         
        
    }
    
}
